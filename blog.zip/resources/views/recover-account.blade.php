@extends('layout.main')

@section('content')


<link rel="stylesheet" type="text/css" href="{{URL::asset('css/login.css')}}">


<div class="login-page">
  <div class="form">
    <form class="login-form" action="{{URL::route('account-recover-post')}}" method="POST">

      <input type="text" placeholder="email" name="email" />


      @if($errors->has('email'))
            <small class="help-block text-danger">
                {{$errors->first('email')}}
            </small>
      @endif

       <!-- render flash message -->
        @if(\Session::has('global'))

            <small class="help-block text-danger">
                {{\Session::get('global')}}
            </small>
            <!-- forget session key -->
            {{\Session::forget('global')}}
               
        @endif 

       <!-- end flash message -->
      <input type="hidden" name="_token" value="{{csrf_token()}}">
      <button>login</button>    
    </form>
  </div>
</div>


@stop