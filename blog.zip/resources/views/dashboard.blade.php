@extends('layout.main')

@section('content')

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
	    $('#table').DataTable();
	});	
</script>

  <div class="panel panel-default">
    
    <div class="panel-heading">User(s)

    	@if(session('global'))

            <small class="help-block text-danger">
                {{session('global')}}
            </small>
               
        @endif  
    	<a href="{{URL::route('create-user')}}" style="float: right">add</a>
    </div>

    <div class="panel-body">
		<table id="table" class="table table-bordered">
			<thead>
				<tr>
					<th>email</th>
					<th>username</th>
					<th>status</th>
					<th>action</th>
				</tr>		
			</thead>

			<tbody>
				<!-- render users from controller -->
				@foreach($users as $user)

					<tr>
						<td>{{$user->email}}</td><!-- column name from database -->
						<td>{{$user->username}}</td>
						<td>{{$user->active}}</td>
						<td>
												<!--URL name, url parameter value  -->
							<a href="{{URL::route('fetchUser',['id' => $user->id])}}">
								Edit
							</a>
							<a href="{{URL::route('deleteUser',['id' => $user->id])}}">
								Delete
							</a>							
							
						</td>
					</tr>

				@endforeach
			</tbody>

		</table>

    </div>
  </div>

@stop