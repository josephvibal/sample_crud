@extends('layout.main')

@section('content')


<link rel="stylesheet" type="text/css" href="{{URL::asset('css/login.css')}}">


<div class="login-page">
  <div class="form">
    <form class="login-form" action="{{URL::route('Postlogin')}}" method="POST">

      <input type="text" placeholder="username" name="username" />
      <input type="password" placeholder="password" name="password" />
      <input type="hidden" name="_token" value="{{csrf_token()}}">

			<div class="checkbox">
			  <label><input type="checkbox" name="remember">Remember Me?</label>
			</div>

       <!-- render flash message -->
        @if(\Session::has('global'))

            <small class="help-block text-danger">
                {{\Session::get('global')}}
            </small>
            <!-- forget session key-->
            {{\Session::forget('global')}}
               
        @endif 

       <!-- end flash message -->

      <button>login</button> 
      <a href="{{URL::route('account-recover')}}">Forgot Password?</a>	  
    </form>
  </div>
</div>


@stop