@extends('layout.main')


@section('content')


  <div class="panel panel-default">
    
    <div class="panel-heading">{{$panelTitle}}</div>

    <div class="panel-body">

    	<!-- dynamic URL for create and edit -->
		<form action="{{$url}}" method="POST">
		  <div class="form-group">
		    <label for="email">Email address</label>
		    <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="{{ (!empty($user)) ? $user->email : old('email')}}">
		    @if($errors->has('email'))
		    <small class="form-text text-muted">{{$errors->first('email')}}</small>
		    @endif
		  </div>

		  <div class="form-group">
		    <label for="username">Username</label>
		    <input type="username" class="form-control" id="username" name="username"  placeholder="Enter username" value="{{ (!empty($user)) ? $user->username : old('username')}}">
		    @if($errors->has('username'))
		    <small class="form-text text-muted">{{$errors->first('username')}}</small>
		    @endif
		  </div>



		  <input type="hidden" name="_token" value="{{csrf_token()}}">

		  @if(!empty($user))
		  	<input type="hidden" name="id" value="{{$user->id}}">
		  @else
		  <div class="form-group">
		    <label for="exampleInputPassword1">Password</label>
		    <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="{{ (!empty($user)) ? $user->password : old('password')}}">

		    @if($errors->has('password'))
		    <small class="form-text text-muted">{{$errors->first('password')}}</small>
		    @endif
		  </div>		  
		  @endif
		  <button type="submit" class="btn btn-primary">{{ (!empty($user)) ? 'Update' : 'Submit'}}</button>
		</form>
		  
    </div>
  
  </div>

@stop