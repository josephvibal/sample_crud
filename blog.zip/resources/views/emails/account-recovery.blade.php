<h1>Hi {{$username}}</h1>

It looks like you requested a new password. You'll need to use the following link to activate it. If you didn't request a new password,please ignore this email.<br/><br/>

New password : {{$newpassword}}<br><br>

---------<br/><br/>

Link : <a href="{{$link}}">click here</a>