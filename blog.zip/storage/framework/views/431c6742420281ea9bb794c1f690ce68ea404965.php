<?php $__env->startSection('content'); ?>


<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/login.css')); ?>">


<div class="login-page">
  <div class="form">
    <form class="login-form" action="<?php echo e(URL::route('Postlogin')); ?>" method="POST">

      <input type="text" placeholder="username" name="username" />
      <input type="password" placeholder="password" name="password" />
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

			<div class="checkbox">
			  <label><input type="checkbox" name="remember">Remember Me?</label>
			</div>

       <!-- render flash message -->
        <?php if(\Session::has('global')): ?>

            <small class="help-block text-danger">
                <?php echo e(\Session::get('global')); ?>

            </small>
            <!-- forget session key-->
            <?php echo e(\Session::forget('global')); ?>

               
        <?php endif; ?> 

       <!-- end flash message -->

      <button>login</button> 
      <a href="<?php echo e(URL::route('account-recover')); ?>">Forgot Password?</a>	  
    </form>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>