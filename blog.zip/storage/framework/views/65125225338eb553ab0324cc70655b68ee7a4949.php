<?php $__env->startSection('content'); ?>


<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/login.css')); ?>">


<div class="login-page">
  <div class="form">
    <form class="login-form" action="<?php echo e(URL::route('account-recover-post')); ?>" method="POST">

      <input type="text" placeholder="email" name="email" />


      <?php if($errors->has('email')): ?>
            <small class="help-block text-danger">
                <?php echo e($errors->first('email')); ?>

            </small>
      <?php endif; ?>

       <!-- render flash message -->
        <?php if(\Session::has('global')): ?>

            <small class="help-block text-danger">
                <?php echo e(\Session::get('global')); ?>

            </small>
            <!-- forget session key -->
            <?php echo e(\Session::forget('global')); ?>

               
        <?php endif; ?> 

       <!-- end flash message -->
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <button>login</button>    
    </form>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>