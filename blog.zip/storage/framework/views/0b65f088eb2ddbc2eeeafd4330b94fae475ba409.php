<!DOCTYPE html>
<html>
<head>
	<title>Sample</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('bootstrap/css/bootstrap.min.css')); ?>">
	<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery-3.2.1.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
</head>
<body>
	<!-- if user is successfully authenticated -->
	<?php if(Auth::user()): ?>

	<nav class="navbar navbar-default">
	    <!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
	        <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
	            <span class="sr-only">Toggle navigation</span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	        </button>
	        <a href="/" class="navbar-brand">Brand</a>
	    </div>
	    <!-- Collection of nav links and other content for toggling -->
	    <div id="navbarCollapse" class="collapse navbar-collapse">
	        <ul class="nav navbar-nav">
	            <li class="active"><a href="/">Home</a></li>
	        </ul>
	        <ul class="nav navbar-nav navbar-right">
	            <a href="<?php echo e(URL::route('logout')); ?>">logout</a>
	        </ul>
	    </div>
	</nav>



	<?php endif; ?>
	<!-- end navbar -->
	<div class="container">

	<?php echo $__env->yieldContent('content'); ?>

	</div>

</body>
</html>