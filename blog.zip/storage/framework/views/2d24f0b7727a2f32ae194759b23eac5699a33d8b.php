<img src="<?php echo e($message->embed(URL::asset('images/logo-infotxt.jpg'))); ?>" style="height:128;width:324px">
<h1>Hi, <?php echo e($username); ?>!</h1>
 
<p style="text-indent: 50px;">	We'd like to personally welcome you to our new website . To complete your registration,  
kindly activate your account by clicking the link <a href="<?php echo e($link); ?>">here</a>.</p>
<br/>
<p style="text-indent: 50px;"> After completing your registration you may now login online.
<br/>
<p>
username : <?php echo e($username); ?><br/>
password : <?php echo e($password); ?>

</p>
<br/><br/>
<p>Thank you for registering!</p>
 
 <p> Site Admin</p>