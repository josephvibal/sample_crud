<?php $__env->startSection('content'); ?>


  <div class="panel panel-default">
    
    <div class="panel-heading"><?php echo e($panelTitle); ?></div>

    <div class="panel-body">

    	<!-- dynamic URL for create and edit -->
		<form action="<?php echo e($url); ?>" method="POST">
		  <div class="form-group">
		    <label for="email">Email address</label>
		    <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo e((!empty($user)) ? $user->email : old('email')); ?>">
		    <?php if($errors->has('email')): ?>
		    <small class="form-text text-muted"><?php echo e($errors->first('email')); ?></small>
		    <?php endif; ?>
		  </div>

		  <div class="form-group">
		    <label for="username">Username</label>
		    <input type="username" class="form-control" id="username" name="username"  placeholder="Enter username" value="<?php echo e((!empty($user)) ? $user->username : old('username')); ?>">
		    <?php if($errors->has('username')): ?>
		    <small class="form-text text-muted"><?php echo e($errors->first('username')); ?></small>
		    <?php endif; ?>
		  </div>



		  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

		  <?php if(!empty($user)): ?>
		  	<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
		  <?php else: ?>
		  <div class="form-group">
		    <label for="exampleInputPassword1">Password</label>
		    <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="<?php echo e((!empty($user)) ? $user->password : old('password')); ?>">

		    <?php if($errors->has('password')): ?>
		    <small class="form-text text-muted"><?php echo e($errors->first('password')); ?></small>
		    <?php endif; ?>
		  </div>		  
		  <?php endif; ?>
		  <button type="submit" class="btn btn-primary"><?php echo e((!empty($user)) ? 'Update' : 'Submit'); ?></button>
		</form>
		  
    </div>
  
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>