<h1>Hi <?php echo e($username); ?></h1>

It looks like you requested a new password. You'll need to use the following link to activate it. If you didn't request a new password,please ignore this email.<br/><br/>

New password : <?php echo e($newpassword); ?><br><br>

---------<br/><br/>

Link : <a href="<?php echo e($link); ?>">click here</a>