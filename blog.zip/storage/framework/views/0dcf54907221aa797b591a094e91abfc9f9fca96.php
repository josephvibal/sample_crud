<?php $__env->startSection('content'); ?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
	    $('#table').DataTable();
	});	
</script>

  <div class="panel panel-default">
    
    <div class="panel-heading">User(s)

    	<?php if(session('global')): ?>

            <small class="help-block text-danger">
                <?php echo e(session('global')); ?>

            </small>
               
        <?php endif; ?>  
    	<a href="<?php echo e(URL::route('create-user')); ?>" style="float: right">add</a>
    </div>

    <div class="panel-body">
		<table id="table" class="table table-bordered">
			<thead>
				<tr>
					<th>email</th>
					<th>username</th>
					<th>status</th>
					<th>action</th>
				</tr>		
			</thead>

			<tbody>
				<!-- render users from controller -->
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<td><?php echo e($user->email); ?></td><!-- column name from database -->
						<td><?php echo e($user->username); ?></td>
						<td><?php echo e($user->active); ?></td>
						<td>
												<!--URL name, url parameter value  -->
							<a href="<?php echo e(URL::route('fetchUser',['id' => $user->id])); ?>">
								Edit
							</a>
							<a href="<?php echo e(URL::route('deleteUser',['id' => $user->id])); ?>">
								Delete
							</a>							
							
						</td>
					</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>

		</table>

    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>