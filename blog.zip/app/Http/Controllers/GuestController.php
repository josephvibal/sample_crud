<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GuestController extends Controller
{

	public function postLogin(Request $request){
		$remember = ($request->has('remember')) ? true : false;
		if (\Auth::attempt(['username' => $request->username, 'password' => $request->password, 'active' => 1],$remember)) {
			return redirect()->route('dashboard');
		}

		return redirect()->back()->with('global','username/password was incorrect');
	}

    public function login(){
    	return view('login');
    }
}
