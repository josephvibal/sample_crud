<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;


class UserController extends Controller
{

	public function passwordRecover($code){
		$user = User::where('code',$code)->first();

		$user->password = $user->password_temp;
		$user->code     = '';
		//store message to a session variable. 
		\session()->put('global','Account Succesfully Recovered'); 
		if($user->update()){
			return redirect('/');
		}
	}

	public function accountRecoverPost(Request $request){
		$validatedData = $this->validate($request,['email' => 'required']);
		
		$user = User::where('email',$request->email)->first();
		
		$code = str_random(60);
		$tmpPassword = str_random(6);

		$user->code 			= $code;
		$user->password_temp	= \Hash::make($tmpPassword);

		if($user->update()){

        \Mail::send('emails.account-recovery', 
        					array(
                                   'link'       	=> \URL::route('password-recover',['code' => $code]), //pass value to url parameter
          						   'username'		=> $user->username,
          						   'newpassword'	=> $tmpPassword
          						), 
				            function($message) use($request)
				            {
				                $message->to($request->email)->subject('No Reply, Welcome!');
				            }
				            
            ); 

		}


	}

	public function accountRecover(){
		return view('recover-account');
	}

	public function delete($id){

		$userDeleted = User::where('id','=',$id)->delete();

		if($userDeleted){
			return redirect('/')->with('global','Account Succesfully deleted');
		}
	}

	public function patch(Request $request){

	    $validatedData = $this->validate($request,[
	    	//https://laravel.com/docs/5.5/validation#rule-unique
	    							  // tablename,columnname,id to be ignored
	        'email' 		=> 'required|email|unique:users,email,'. $request->id .'|max:60',
	        'username' 		=> 'required|unique:users,username,'. $request->id .'|max:60',

	    ]);

	    $user = User::findOrFail($request->id);

	    $user->email 	= $request->email;
	    $user->username = $request->username;

	    if($user->update()){
	    	return redirect('/')->with('global','Account Succesfully updated');
	    }

	}

	public function fetchUser($id){

		$user = User::findOrFail($id);// built in laravel eloquent ORM https://laravel.com/docs/5.5/eloquent#retrieving-single-models
		$url = \URL::route('userUpdate');
		$panelTitle = 'Update User';
		return view('create')
				->with('panelTitle',$panelTitle)
				->with('user',$user)
				->with('url',$url);
	}

	public function accountActivate($code){
		$user = User::where('code','=',$code);

		//check if there is any row
		if(!$user->count()){
			\App::abort(404);	
		}

		$user = $user->first();
		
		$user->active = 1;
		$user->code = '';
		//store message to a session variable. 
		\session()->put('global','Account Succesfully Activated'); 
	
		if($user->update()){

			return redirect('/');
		}
	}

	public function store(Request $request){


    $validatedData = $this->validate($request,[
    	//https://laravel.com/docs/5.5/validation#rule-unique
    							  // tablename,columnname
        'email' 		=> 'required|email|unique:users,email|max:60',
        'username' 		=> 'required|unique:users,username|max:60',
        'password'		=> 'required'
    ]);
    	$code = str_random(60);// generate 60 character random string


        $userCreate = User::create([

        							 'username' => $request->username,
        							 'email'	=> $request->email,
        							 'password' => \Hash::make($request->password),
        							 'code' 	=> $code,
        							 'active'	=> 0

        							]);

        if($userCreate){

        \Mail::send('emails.welcome', 
        					array(
                                   'link'       => \URL::route('account-activate',['code' => $code]), //pass value to url parameter
          						   'username'	=> $request->username,
          						   'password'	=> $request->password
          						), 
				            function($message) use($request)
				            {
				                $message->to($request->email)->subject('No Reply, Welcome!');
				            }
				            
            ); 

        return redirect('/')->with('global','Account Succesfully created');

        }

    	

	}

	public function create(Request $request){
		$url = \URL::route('store-user');
		$panelTitle = 'Create User';
		return view('create')
		->with('panelTitle',$panelTitle)
		->with('url',$url);
	}

	public function index(){
		$users = User::get(); //fetch all data from users table
		return view('dashboard')->with('users',$users);
	}

    public function logout(){
  		\Auth::logout();
  		return redirect('/login')->with('global','You have logged out.');    	
    }
}
