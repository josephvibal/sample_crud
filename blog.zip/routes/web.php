<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



//Routes that are grouped for unauthenticated users
Route::group(['middleware' => ['guest','web']], function () {


	Route::get('/password-recover/{code}',[

		'as' 	=>	'password-recover',
		'uses'	=>	'UserController@passwordRecover'
	]);



	Route::post('/account-recover',[

		'as' 	=>	'account-recover-post',
		'uses'	=>	'UserController@accountRecoverPost'
	]);	

	Route::get('/account-recover',[

		'as' 	=>	'account-recover',
		'uses'	=>	'UserController@accountRecover'
	]);	

	Route::get('/account-activate/{code}',[

		'as' 	=>	'account-activate',
		'uses'	=>	'UserController@accountActivate'
	]);

	Route::get('/login',[

		'as'	=>	'login',
		'uses'	=>	'GuestController@login'
	]);

	Route::post('/login',[

		'as'	=>	'Postlogin',
		'uses'	=>	'GuestController@postLogin'
	]);

});

//Routes that are grouped for authenticated users
Route::group(['middleware' => ['auth']], function () {

	//delete record
	// sir GET nlng po gnamit ko d2, pero dapat tlga post
	Route::get('user/delete/{id}',[
		'as'	=> 'deleteUser',
		'uses'	=> 'UserController@delete'
	]);

	//update data
	Route::post('/user/update',[
		'as'	=>	'userUpdate',
		'uses'	=>	'UserController@patch'
	]);

	//fetch user to be updated
	Route::get('/user/id/{id}',[
		'as'	=> 'fetchUser',
		'uses'	=> 'UserController@fetchUser'
	]);

	//user save to db route
	Route::post('/user/store',[
		'as' 	=> 'store-user',
		'uses'	=> 'UserController@store'
	]);

	//user create form route
	Route::get('/user/create',[
		'as'	=> 'create-user',
		'uses'	=> 'UserController@create'
	]);


	//home page
	Route::get('/',[
		'as'	=> 'dashboard',
		'uses'	=> 'UserController@index'
	]);

	//logout
	Route::get('/logout',[

		'as'	=> 'logout',
		'uses'	=> 'UserController@logout'
	]);



});
